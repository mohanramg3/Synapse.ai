import { createFileRoute } from "@tanstack/react-router";
import { makePlaceholder } from "@/components/common/Placeholder";

export const Route = createFileRoute("/_app/documents")({
  head: () => ({
    meta: [
      { title: "Documents — Atlas" },
      { name: "description", content: "Drag-and-drop uploads, extraction, chunking, AI analysis, and processing logs." },
    ],
  }),
  component: makePlaceholder("Documents", "Drag-and-drop uploads, extraction, chunking, AI analysis, and processing logs."),
});
