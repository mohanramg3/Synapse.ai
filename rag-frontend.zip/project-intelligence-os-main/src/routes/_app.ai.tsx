import { createFileRoute } from "@tanstack/react-router";
import { makePlaceholder } from "@/components/common/Placeholder";

export const Route = createFileRoute("/_app/ai")({
  head: () => ({
    meta: [
      { title: "AI Insights — Atlas" },
      { name: "description", content: "Summaries, missing requirements, architecture suggestions, and risk detection." },
    ],
  }),
  component: makePlaceholder("AI Insights", "Summaries, missing requirements, architecture suggestions, and risk detection."),
});
