import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";
import { Search, FolderKanban, SlidersHorizontal, Plus } from "lucide-react";
import { useProjectStore } from "@/store/projectStore";
import { PageHeader, EmptyState, Skeleton } from "@/components/common/Primitives";
import { ProjectCard } from "@/components/projects/ProjectCard";

export const Route = createFileRoute("/_app/projects/")({
  head: () => ({
    meta: [
      { title: "Projects — Atlas" },
      { name: "description", content: "All AI-generated execution workspaces with live health, risk, and progress." },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const { projects, loading, fetchProjects, filters, setFilter } = useProjectStore();

  useEffect(() => {
    void fetchProjects();
  }, [fetchProjects]);

  const filtered = useMemo(() => {
    let items = [...projects];
    if (filters.search.trim()) {
      const q = filters.search.toLowerCase();
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.description ?? "").toLowerCase().includes(q),
      );
    }
    if (filters.status) items = items.filter((p) => p.status === filters.status);
    if (filters.minHealth !== null)
      items = items.filter((p) => (p.health_score ?? 0) >= filters.minHealth!);
    if (filters.sortBy === "name")
      items.sort((a, b) => a.name.localeCompare(b.name));
    else if (filters.sortBy === "health")
      items.sort((a, b) => (b.health_score ?? 0) - (a.health_score ?? 0));
    else
      items.sort((a, b) =>
        (b.updated_at ?? "").localeCompare(a.updated_at ?? ""),
      );
    return items;
  }, [projects, filters]);

  const statuses = useMemo(() => {
    const set = new Set<string>();
    projects.forEach((p) => p.status && set.add(p.status));
    return Array.from(set);
  }, [projects]);

  return (
    <div>
      <PageHeader
        eyebrow="Workspaces"
        title="Projects"
        description="Each project is an AI-generated execution workspace built from your documents."
        actions={
          <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-primary px-3 text-xs font-medium text-primary-foreground transition hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /> New Project
          </button>
        }
      />

      {/* Filter bar */}
      <div className="mb-6 flex flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-3">
        <div className="flex h-9 flex-1 min-w-[240px] items-center gap-2 rounded-md border border-border bg-surface/60 px-3">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={filters.search}
            onChange={(e) => setFilter("search", e.target.value)}
            placeholder="Search projects, descriptions…"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
        <select
          value={filters.status ?? ""}
          onChange={(e) => setFilter("status", e.target.value || null)}
          className="h-9 rounded-md border border-border bg-surface/60 px-3 text-xs"
        >
          <option value="">All statuses</option>
          {statuses.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <select
          value={filters.sortBy}
          onChange={(e) => setFilter("sortBy", e.target.value as typeof filters.sortBy)}
          className="h-9 rounded-md border border-border bg-surface/60 px-3 text-xs"
        >
          <option value="updated">Recently updated</option>
          <option value="name">Name (A–Z)</option>
          <option value="health">Health score</option>
        </select>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border bg-surface/60 px-3 text-xs">
          <SlidersHorizontal className="h-3.5 w-3.5" /> More filters
        </button>
      </div>

      {loading && projects.length === 0 ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="No projects match"
          description="Try clearing filters or upload a document to spin up a new workspace."
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p, i) => (
            <ProjectCard key={p.id} project={p} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}
