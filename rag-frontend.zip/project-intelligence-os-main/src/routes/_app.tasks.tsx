import { createFileRoute } from "@tanstack/react-router";
import { makePlaceholder } from "@/components/common/Placeholder";

export const Route = createFileRoute("/_app/tasks")({
  head: () => ({
    meta: [
      { title: "Tasks — Atlas" },
      { name: "description", content: "Linear-style task surface with kanban, list, and module grouping." },
    ],
  }),
  component: makePlaceholder("Tasks", "Linear-style task surface with kanban, list, and module grouping."),
});
