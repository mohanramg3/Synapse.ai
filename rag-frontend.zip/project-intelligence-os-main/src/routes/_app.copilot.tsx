import { createFileRoute } from "@tanstack/react-router";
import { makePlaceholder } from "@/components/common/Placeholder";

export const Route = createFileRoute("/_app/copilot")({
  head: () => ({
    meta: [
      { title: "AI Copilot — Atlas" },
      { name: "description", content: "Always-on copilot for execution decisions and document analysis." },
    ],
  }),
  component: makePlaceholder("AI Copilot", "Always-on copilot for execution decisions and document analysis."),
});
