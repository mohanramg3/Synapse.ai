import { apiClient } from "./client";

export type Task = {
  id: string;
  title: string;
  description?: string;
  status?: string;
  priority?: string;
  due_date?: string;
  assignee?: { id: string; name?: string; avatar_url?: string };
  module_id?: string;
  module_name?: string;
  checklist?: Array<{ id: string; label: string; done?: boolean }>;
  project_id?: string;
  [key: string]: unknown;
};

export const taskApi = {
  list: () => apiClient.get<Task[]>("/tasks").then((r) => r.data),
  byProject: (projectId: string) =>
    apiClient.get<Task[]>(`/tasks/project/${projectId}`).then((r) => r.data),
  update: (id: string, patch: Partial<Task>) =>
    apiClient.patch<Task>(`/tasks/${id}`, patch).then((r) => r.data),
};
