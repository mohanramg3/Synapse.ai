import axios, { type AxiosInstance, type InternalAxiosRequestConfig } from "axios";

const TOKEN_KEY = "atlas.auth.token";

export const getStoredToken = (): string | null => {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
};

export const setStoredToken = (token: string | null): void => {
  if (typeof window === "undefined") return;
  if (token) window.localStorage.setItem(TOKEN_KEY, token);
  else window.localStorage.removeItem(TOKEN_KEY);
};

const baseURL =
  (typeof import.meta !== "undefined" && import.meta.env?.VITE_API_BASE_URL) ||
  "http://localhost:8000";

export const apiClient: AxiosInstance = axios.create({
  baseURL,
  timeout: 30000,
  headers: { "Content-Type": "application/json" },
});

apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = getStoredToken();
  if (token) {
    config.headers = config.headers ?? {};
    (config.headers as Record<string, string>).Authorization = `Bearer ${token}`;
  }
  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Centralized error normalization. Refresh-token logic can hook here later.
    if (error?.response?.status === 401) {
      // Token invalid — clear and let route guards redirect.
      setStoredToken(null);
    }
    return Promise.reject(error);
  },
);

export type ApiError = {
  status?: number;
  message: string;
  detail?: unknown;
};

export const toApiError = (err: unknown): ApiError => {
  if (axios.isAxiosError(err)) {
    return {
      status: err.response?.status,
      message:
        (err.response?.data as { detail?: string; message?: string } | undefined)?.detail ||
        (err.response?.data as { message?: string } | undefined)?.message ||
        err.message,
      detail: err.response?.data,
    };
  }
  if (err instanceof Error) return { message: err.message };
  return { message: "Unknown error" };
};
