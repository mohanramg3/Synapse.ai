import { apiClient } from "./client";

// Loose, dynamic shapes — backend is the source of truth. We never hardcode modules.
export type ProjectSummary = {
  id: string;
  name: string;
  description?: string;
  status?: string;
  progress?: number;
  health_score?: number;
  risk_level?: "low" | "medium" | "high" | string;
  members?: Array<{ id: string; name?: string; avatar_url?: string }>;
  document_count?: number;
  task_count?: number;
  updated_at?: string;
  created_at?: string;
  [key: string]: unknown;
};

export type ProjectDetail = ProjectSummary & {
  ai_summary?: string;
  modules?: Array<Record<string, unknown>>;
  tasks?: Array<Record<string, unknown>>;
  risks?: Array<Record<string, unknown>>;
  dependencies?: Array<Record<string, unknown>>;
  recommendations?: Array<Record<string, unknown>>;
  documents?: Array<Record<string, unknown>>;
  team_activity?: Array<Record<string, unknown>>;
  [key: string]: unknown;
};

export type ProjectDashboard = {
  active_projects?: number;
  pending_tasks?: number;
  documents_processed?: number;
  ai_insights?: number;
  health_average?: number;
  recent_activity?: Array<Record<string, unknown>>;
  processing_queue?: Array<Record<string, unknown>>;
  recommendations?: Array<Record<string, unknown>>;
  trends?: Array<Record<string, unknown>>;
  [key: string]: unknown;
};

export const projectApi = {
  list: () => apiClient.get<ProjectSummary[]>("/projects").then((r) => r.data),
  get: (id: string) => apiClient.get<ProjectDetail>(`/projects/${id}`).then((r) => r.data),
  dashboard: (id?: string) =>
    apiClient
      .get<ProjectDashboard>(id ? `/projects/${id}/dashboard` : `/projects/dashboard`)
      .then((r) => r.data),
  create: (payload: Partial<ProjectSummary>) =>
    apiClient.post<ProjectSummary>("/projects", payload).then((r) => r.data),
};
