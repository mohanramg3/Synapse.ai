import { apiClient } from "./client";

export type DocumentRecord = {
  id: string;
  name: string;
  size?: number;
  mime_type?: string;
  project_id?: string;
  status?: "uploading" | "extracting" | "chunking" | "analyzing" | "ready" | "failed" | string;
  chunk_count?: number;
  ai_summary?: string;
  risk_level?: string;
  uploaded_at?: string;
  [key: string]: unknown;
};

export const documentApi = {
  list: (projectId?: string) =>
    apiClient
      .get<DocumentRecord[]>("/documents", { params: projectId ? { project_id: projectId } : {} })
      .then((r) => r.data),
  upload: (file: File, projectId?: string, onProgress?: (p: number) => void) => {
    const form = new FormData();
    form.append("file", file);
    if (projectId) form.append("project_id", projectId);
    return apiClient
      .post<DocumentRecord>("/documents/upload", form, {
        headers: { "Content-Type": "multipart/form-data" },
        onUploadProgress: (e) => {
          if (onProgress && e.total) onProgress(Math.round((e.loaded / e.total) * 100));
        },
      })
      .then((r) => r.data);
  },
};
