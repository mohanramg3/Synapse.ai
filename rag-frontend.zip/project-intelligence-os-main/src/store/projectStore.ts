import { create } from "zustand";
import { projectApi, type ProjectDashboard, type ProjectDetail, type ProjectSummary } from "@/lib/api/projectApi";
import { toApiError } from "@/lib/api/client";

type Filters = {
  search: string;
  status: string | null;
  priority: string | null;
  minHealth: number | null;
  sortBy: "updated" | "name" | "health";
};

type ProjectState = {
  projects: ProjectSummary[];
  byId: Record<string, ProjectDetail>;
  dashboard: ProjectDashboard | null;
  loading: boolean;
  error: string | null;
  filters: Filters;
  setFilter: <K extends keyof Filters>(key: K, value: Filters[K]) => void;
  fetchProjects: () => Promise<void>;
  fetchProject: (id: string) => Promise<void>;
  fetchDashboard: () => Promise<void>;
};

export const useProjectStore = create<ProjectState>((set) => ({
  projects: [],
  byId: {},
  dashboard: null,
  loading: false,
  error: null,
  filters: { search: "", status: null, priority: null, minHealth: null, sortBy: "updated" },

  setFilter: (key, value) =>
    set((s) => ({ filters: { ...s.filters, [key]: value } })),

  fetchProjects: async () => {
    set({ loading: true, error: null });
    try {
      const projects = await projectApi.list();
      set({ projects, loading: false });
    } catch (err) {
      set({ loading: false, error: toApiError(err).message });
    }
  },

  fetchProject: async (id) => {
    set({ loading: true, error: null });
    try {
      const detail = await projectApi.get(id);
      set((s) => ({ byId: { ...s.byId, [id]: detail }, loading: false }));
    } catch (err) {
      set({ loading: false, error: toApiError(err).message });
    }
  },

  fetchDashboard: async () => {
    set({ loading: true, error: null });
    try {
      const dashboard = await projectApi.dashboard();
      set({ dashboard, loading: false });
    } catch (err) {
      set({ loading: false, error: toApiError(err).message });
    }
  },
}));
