import { create } from "zustand";
import { aiApi, type AIModule, type AIRisk, type AISummary } from "@/lib/api/aiApi";
import { toApiError } from "@/lib/api/client";

type AIState = {
  summaries: Record<string, AISummary>;
  modules: Record<string, AIModule[]>;
  risks: Record<string, AIRisk[]>;
  loading: Record<string, boolean>;
  error: string | null;
  fetchAll: (projectId: string) => Promise<void>;
  triggerAnalysis: (projectId: string) => Promise<void>;
};

export const useAIStore = create<AIState>((set) => ({
  summaries: {},
  modules: {},
  risks: {},
  loading: {},
  error: null,

  fetchAll: async (projectId) => {
    set((s) => ({ loading: { ...s.loading, [projectId]: true }, error: null }));
    try {
      const [summary, modules, risks] = await Promise.allSettled([
        aiApi.summary(projectId),
        aiApi.modules(projectId),
        aiApi.risks(projectId),
      ]);
      set((s) => ({
        summaries:
          summary.status === "fulfilled" ? { ...s.summaries, [projectId]: summary.value } : s.summaries,
        modules:
          modules.status === "fulfilled" ? { ...s.modules, [projectId]: modules.value } : s.modules,
        risks: risks.status === "fulfilled" ? { ...s.risks, [projectId]: risks.value } : s.risks,
        loading: { ...s.loading, [projectId]: false },
      }));
    } catch (err) {
      set((s) => ({
        loading: { ...s.loading, [projectId]: false },
        error: toApiError(err).message,
      }));
    }
  },

  triggerAnalysis: async (projectId) => {
    try {
      await aiApi.analyze(projectId);
    } catch (err) {
      set({ error: toApiError(err).message });
    }
  },
}));
