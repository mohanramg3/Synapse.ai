import { create } from "zustand";
import { taskApi, type Task } from "@/lib/api/taskApi";
import { toApiError } from "@/lib/api/client";

type TaskState = {
  tasks: Task[];
  byProject: Record<string, Task[]>;
  loading: boolean;
  error: string | null;
  fetchAll: () => Promise<void>;
  fetchByProject: (projectId: string) => Promise<void>;
};

export const useTaskStore = create<TaskState>((set) => ({
  tasks: [],
  byProject: {},
  loading: false,
  error: null,

  fetchAll: async () => {
    set({ loading: true, error: null });
    try {
      const tasks = await taskApi.list();
      set({ tasks, loading: false });
    } catch (err) {
      set({ loading: false, error: toApiError(err).message });
    }
  },

  fetchByProject: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const tasks = await taskApi.byProject(projectId);
      set((s) => ({ byProject: { ...s.byProject, [projectId]: tasks }, loading: false }));
    } catch (err) {
      set({ loading: false, error: toApiError(err).message });
    }
  },
}));
